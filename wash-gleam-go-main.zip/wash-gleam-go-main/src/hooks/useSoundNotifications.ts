import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const useSoundNotifications = () => {
  const { user } = useAuth();
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchPreference();
    }
  }, [user]);

  const fetchPreference = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('sound_notifications_enabled')
        .eq('user_id', user.id)
        .single();

      if (!error && data) {
        setSoundEnabled(data.sound_notifications_enabled ?? true);
      }
    } catch (error) {
      console.error('Error fetching sound preference:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSound = async () => {
    if (!user) return;

    const newValue = !soundEnabled;
    setSoundEnabled(newValue);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ sound_notifications_enabled: newValue })
        .eq('user_id', user.id);

      if (error) {
        // Revert on error
        setSoundEnabled(!newValue);
        throw error;
      }
    } catch (error) {
      console.error('Error updating sound preference:', error);
    }
  };

  return { soundEnabled, toggleSound, loading };
};
