import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface UseSplasherLocationTrackingProps {
  userId: string | undefined;
  hasActiveJob: boolean;
  updateIntervalMs?: number;
}

export const useSplasherLocationTracking = ({
  userId,
  hasActiveJob,
  updateIntervalMs = 10000, // Update every 10 seconds by default
}: UseSplasherLocationTrackingProps) => {
  const watchIdRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(0);

  const updateLocation = useCallback(async (latitude: number, longitude: number) => {
    if (!userId) return;

    // Throttle updates to avoid too many database writes
    const now = Date.now();
    if (now - lastUpdateRef.current < updateIntervalMs) return;
    lastUpdateRef.current = now;

    const { error } = await supabase
      .from('splasher_profiles')
      .update({
        current_latitude: latitude,
        current_longitude: longitude,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', userId);

    if (error) {
      console.error('Failed to update location:', error);
    }
  }, [userId, updateIntervalMs]);

  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      toast.error('Geolocation is not supported by your browser');
      return;
    }

    // Clear any existing watch
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        updateLocation(position.coords.latitude, position.coords.longitude);
      },
      (error) => {
        console.error('Geolocation error:', error);
        if (error.code === error.PERMISSION_DENIED) {
          toast.error('Location access denied. Please enable location services.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000,
      }
    );

    toast.success('Location tracking started');
  }, [updateLocation]);

  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
  }, []);

  // Auto start/stop tracking based on active job status
  useEffect(() => {
    if (hasActiveJob && userId) {
      startTracking();
    } else {
      stopTracking();
    }

    return () => {
      stopTracking();
    };
  }, [hasActiveJob, userId, startTracking, stopTracking]);

  return {
    startTracking,
    stopTracking,
    isTracking: watchIdRef.current !== null,
  };
};
