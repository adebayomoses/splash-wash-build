import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js';

type ServiceRequestPayload = {
  id: string;
  status: string;
  service_type: string;
  vehicle_make: string;
  vehicle_model: string;
  location_address: string;
  customer_id: string;
  splasher_id: string | null;
  estimated_price: number | null;
};

interface UseRealtimeNotificationsProps {
  userId: string | undefined;
  userRole: 'customer' | 'splasher';
  onUpdate?: () => void;
}

// Request browser notification permission
const requestNotificationPermission = async () => {
  if (!('Notification' in window)) {
    console.log('This browser does not support notifications');
    return false;
  }
  
  if (Notification.permission === 'granted') {
    return true;
  }
  
  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  
  return false;
};

// Show browser notification
const showBrowserNotification = (title: string, body: string, icon?: string) => {
  if (Notification.permission === 'granted') {
    const notification = new Notification(title, {
      body,
      icon: icon || '/favicon.ico',
      tag: 'splash-notification',
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    // Auto-close after 10 seconds
    setTimeout(() => notification.close(), 10000);
  }
};

export const useRealtimeNotifications = ({
  userId,
  userRole,
  onUpdate,
}: UseRealtimeNotificationsProps) => {
  const previousRequestsRef = useRef<Map<string, string>>(new Map());
  const permissionRequestedRef = useRef(false);

  // Request permission on mount
  useEffect(() => {
    if (!permissionRequestedRef.current && userId) {
      permissionRequestedRef.current = true;
      requestNotificationPermission();
    }
  }, [userId]);

  const notifyCustomer = useCallback((status: string, vehicleMake: string, vehicleModel: string, serviceType: string) => {
    const vehicle = `${vehicleMake} ${vehicleModel}`;
    const service = serviceType.replace('_', ' ');

    switch (status) {
      case 'accepted':
        toast.success('🎉 Splasher accepted your request!', {
          description: `Your ${service} for ${vehicle} has been accepted.`,
          duration: 10000,
        });
        showBrowserNotification(
          'Splasher Accepted!',
          `Your ${service} for ${vehicle} has been accepted. They're on their way!`
        );
        break;
      case 'in_progress':
        toast.info('🚿 Service in progress!', {
          description: `Your Splasher has started working on your ${vehicle}.`,
          duration: 8000,
        });
        showBrowserNotification(
          'Service Started',
          `Your Splasher has started working on your ${vehicle}.`
        );
        break;
      case 'completed':
        toast.success('✅ Service completed!', {
          description: `Your ${vehicle} is ready! Don't forget to rate your Splasher.`,
          duration: 10000,
        });
        showBrowserNotification(
          'Service Completed!',
          `Your ${vehicle} is sparkling clean! Don't forget to rate your Splasher.`
        );
        break;
      case 'cancelled':
        toast.error('Request cancelled', {
          description: `Your request for ${vehicle} was cancelled.`,
          duration: 8000,
        });
        break;
    }
  }, []);

  const notifySplasher = useCallback((status: string, vehicleMake: string, vehicleModel: string) => {
    const vehicle = `${vehicleMake} ${vehicleModel}`;

    if (status === 'cancelled') {
      toast.warning('Job cancelled', {
        description: `The job for ${vehicle} was cancelled by the customer.`,
        duration: 8000,
      });
      showBrowserNotification(
        'Job Cancelled',
        `The customer cancelled the job for ${vehicle}.`
      );
    }
  }, []);

  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel('realtime-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'service_requests',
        },
        (payload: RealtimePostgresChangesPayload<ServiceRequestPayload>) => {
          const newRequest = payload.new as ServiceRequestPayload;
          
          // Notify splashers about new job requests
          if (userRole === 'splasher' && newRequest.status === 'pending') {
            const service = newRequest.service_type.replace('_', ' ');
            const vehicle = `${newRequest.vehicle_make} ${newRequest.vehicle_model}`;
            
            toast.info('🚗 New job available!', {
              description: `${service} - ${vehicle}`,
              duration: 8000,
              action: {
                label: 'View',
                onClick: () => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }),
              },
            });
            
            showBrowserNotification(
              'New Job Available!',
              `${service} - ${vehicle} at ${newRequest.location_address}`
            );
          }
          
          onUpdate?.();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'service_requests',
        },
        (payload: RealtimePostgresChangesPayload<ServiceRequestPayload>) => {
          const updated = payload.new as ServiceRequestPayload;
          const oldStatus = previousRequestsRef.current.get(updated.id);
          
          // Only notify if status actually changed
          if (oldStatus === updated.status) {
            previousRequestsRef.current.set(updated.id, updated.status);
            return;
          }
          
          previousRequestsRef.current.set(updated.id, updated.status);

          // Customer notifications
          if (userRole === 'customer' && updated.customer_id === userId) {
            notifyCustomer(updated.status, updated.vehicle_make, updated.vehicle_model, updated.service_type);
          }

          // Splasher notifications (for their accepted jobs)
          if (userRole === 'splasher' && updated.splasher_id === userId) {
            notifySplasher(updated.status, updated.vehicle_make, updated.vehicle_model);
          }

          onUpdate?.();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, userRole, onUpdate, notifyCustomer, notifySplasher]);
};
