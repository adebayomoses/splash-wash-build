import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

type AppRole = 'customer' | 'splasher';

export const useUserRole = () => {
  const { user } = useAuth();
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSplasher, setIsSplasher] = useState(false);

  useEffect(() => {
    const fetchRoles = async () => {
      if (!user) {
        setRoles([]);
        setIsSplasher(false);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);

      if (error) {
        console.error('Error fetching roles:', error);
        setLoading(false);
        return;
      }

      const userRoles = data?.map(r => r.role as AppRole) || [];
      setRoles(userRoles);
      setIsSplasher(userRoles.includes('splasher'));
      setLoading(false);
    };

    fetchRoles();
  }, [user]);

  return { roles, isSplasher, loading };
};
