import { createContext, useContext, useState, useRef, ReactNode } from 'react';

interface ViewModeContextType {
  viewMode: 'customer' | 'splasher';
  setViewMode: (mode: 'customer' | 'splasher') => void;
  openNewRequestRef: React.MutableRefObject<(() => void) | null>;
  triggerNewRequest: () => void;
}

const ViewModeContext = createContext<ViewModeContextType | undefined>(undefined);

export const ViewModeProvider = ({ children }: { children: ReactNode }) => {
  const [viewMode, setViewMode] = useState<'customer' | 'splasher'>('customer');
  const openNewRequestRef = useRef<(() => void) | null>(null);

  const triggerNewRequest = () => {
    openNewRequestRef.current?.();
  };

  return (
    <ViewModeContext.Provider value={{ viewMode, setViewMode, openNewRequestRef, triggerNewRequest }}>
      {children}
    </ViewModeContext.Provider>
  );
};

export const useViewMode = () => {
  const context = useContext(ViewModeContext);
  if (!context) {
    throw new Error('useViewMode must be used within a ViewModeProvider');
  }
  return context;
};
