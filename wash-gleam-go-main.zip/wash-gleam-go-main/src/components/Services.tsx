import { Car, Droplets, Snowflake, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Droplets,
    title: "Premium Car Wash",
    description: "Thorough exterior and interior cleaning with premium products that protect your paint and leave a brilliant shine.",
    features: ["Exterior Hand Wash", "Tire & Wheel Cleaning", "Window Polish", "Air Freshener"],
    price: "From $29",
    popular: false,
  },
  {
    icon: Sparkles,
    title: "Full Detailing",
    description: "Complete restoration service including paint correction, ceramic coating, and deep interior cleaning.",
    features: ["Paint Correction", "Ceramic Coating", "Leather Treatment", "Engine Bay Clean"],
    price: "From $199",
    popular: true,
  },
  {
    icon: Snowflake,
    title: "De-Icing Service",
    description: "Professional ice and snow removal to protect your vehicle during harsh winter conditions.",
    features: ["Ice Removal", "Salt Treatment", "Undercarriage Flush", "Weather Protection"],
    price: "From $49",
    popular: false,
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Car className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Our Services</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Premium Care for Your
            <span className="splash-gradient-text"> Vehicle</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Choose from our range of professional car care services designed to keep your vehicle in pristine condition.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`relative group rounded-2xl p-8 transition-all duration-500 hover:-translate-y-2 ${
                service.popular
                  ? "bg-gradient-to-br from-primary to-accent text-primary-foreground splash-shadow"
                  : "bg-card border border-border hover:border-primary/30 hover:shadow-xl"
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Popular Badge */}
              {service.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-background text-primary text-xs font-semibold">
                  Most Popular
                </div>
              )}

              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 ${
                service.popular 
                  ? "bg-primary-foreground/20" 
                  : "splash-gradient"
              }`}>
                <service.icon className={`w-7 h-7 ${service.popular ? "text-primary-foreground" : "text-primary-foreground"}`} />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold mb-3">{service.title}</h3>
              <p className={`mb-6 ${service.popular ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <div className={`w-1.5 h-1.5 rounded-full ${service.popular ? "bg-primary-foreground" : "bg-primary"}`} />
                    <span className={`text-sm ${service.popular ? "text-primary-foreground/90" : "text-muted-foreground"}`}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* Price & CTA */}
              <div className="flex items-center justify-between pt-6 border-t border-current/10">
                <span className="text-2xl font-bold">{service.price}</span>
                <Button 
                  variant={service.popular ? "hero" : "default"}
                  size="sm"
                  className="group/btn"
                >
                  Book Now
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
