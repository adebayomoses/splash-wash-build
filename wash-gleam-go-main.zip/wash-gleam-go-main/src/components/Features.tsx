import { Leaf, Clock, Award, MapPin, CreditCard, Phone } from "lucide-react";

const features = [
  {
    icon: Leaf,
    title: "Eco-Friendly",
    description: "We use biodegradable, water-saving products that are gentle on your car and the environment.",
  },
  {
    icon: Clock,
    title: "Quick Turnaround",
    description: "Most services completed within 30-90 minutes. We value your time as much as your car.",
  },
  {
    icon: Award,
    title: "Expert Team",
    description: "Our certified detailers have years of experience caring for vehicles of all types.",
  },
  {
    icon: MapPin,
    title: "Mobile Service",
    description: "We come to you! Book our mobile unit for convenient at-home or office service.",
  },
  {
    icon: CreditCard,
    title: "Easy Payment",
    description: "Flexible payment options including cards, mobile payments, and membership plans.",
  },
  {
    icon: Phone,
    title: "24/7 Booking",
    description: "Book your appointment anytime through our app or website. Easy rescheduling available.",
  },
];

const Features = () => {
  return (
    <section className="py-24 bg-muted/30 relative overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Why Choose
            <span className="splash-gradient-text"> Splash?</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            We're committed to providing the best car care experience with modern convenience and exceptional quality.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group p-8 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl splash-gradient flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
