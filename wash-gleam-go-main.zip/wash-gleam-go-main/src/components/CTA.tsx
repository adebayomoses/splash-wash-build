import { Button } from "@/components/ui/button";
import { ArrowRight, Droplets } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="relative rounded-3xl splash-gradient p-12 md:p-20 text-center overflow-hidden">
          {/* Background Decorations */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-10 left-10 w-32 h-32 bg-primary-foreground/10 rounded-full blur-2xl" />
            <div className="absolute bottom-10 right-10 w-40 h-40 bg-primary-foreground/10 rounded-full blur-2xl" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary-foreground/5 rounded-full blur-3xl" />
          </div>

          <div className="relative z-10 max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="p-4 rounded-full bg-primary-foreground/20 backdrop-blur-sm">
                <Droplets className="w-10 h-10 text-primary-foreground" />
              </div>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-6">
              Ready for a Sparkling Clean Car?
            </h2>
            
            <p className="text-lg text-primary-foreground/80 mb-10 max-w-xl mx-auto">
              Book your appointment today and experience the Splash difference. 
              First-time customers get 20% off their first service!
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button variant="hero" size="lg" className="group">
                Book Your Wash
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button 
                variant="ghost" 
                size="lg" 
                className="text-primary-foreground hover:bg-primary-foreground/10"
              >
                Call Us Now
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
