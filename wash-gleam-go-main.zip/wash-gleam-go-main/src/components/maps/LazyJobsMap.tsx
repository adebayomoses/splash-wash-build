import StaticJobsMap from './StaticJobsMap';

type Job = {
  id: string;
  location_latitude: number;
  location_longitude: number;
  location_address: string;
  service_type: string;
  vehicle_make: string;
  vehicle_model: string;
  estimated_price: number | null;
  status: string;
};

type LazyJobsMapProps = {
  jobs: Job[];
  activeJobs?: Job[];
  onJobClick?: (job: Job) => void;
  className?: string;
};

// Simple wrapper that uses the static map (no react-leaflet)
const LazyJobsMap = ({ jobs, activeJobs = [], onJobClick, className = '' }: LazyJobsMapProps) => {
  return (
    <StaticJobsMap
      jobs={jobs}
      activeJobs={activeJobs}
      onJobClick={onJobClick}
      className={className}
    />
  );
};

export default LazyJobsMap;
