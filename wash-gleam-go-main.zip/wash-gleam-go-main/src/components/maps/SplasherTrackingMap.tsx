import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { supabase } from '@/integrations/supabase/client';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icons
const customerIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const splasherIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Car icon for splasher
const carIcon = new L.DivIcon({
  html: `<div style="background: hsl(217, 91%, 60%); width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/>
      <circle cx="7" cy="17" r="2"/>
      <path d="M9 17h6"/>
      <circle cx="17" cy="17" r="2"/>
    </svg>
  </div>`,
  className: '',
  iconSize: [36, 36],
  iconAnchor: [18, 18],
});

type SplasherTrackingMapProps = {
  requestId: string;
  splasherId: string | null;
  customerLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  status: string;
  className?: string;
};

// Component to center map on markers
const CenterMap = ({ positions }: { positions: [number, number][] }) => {
  const map = useMap();
  
  useEffect(() => {
    if (positions.length === 0) return;
    
    if (positions.length === 1) {
      map.setView(positions[0], 14);
    } else {
      const bounds = L.latLngBounds(positions);
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    }
  }, [positions, map]);
  
  return null;
};

const SplasherTrackingMap = ({ 
  requestId, 
  splasherId, 
  customerLocation, 
  status,
  className = '' 
}: SplasherTrackingMapProps) => {
  const [splasherLocation, setSplasherLocation] = useState<{
    lat: number;
    lng: number;
  } | null>(null);

  // Fetch splasher location
  useEffect(() => {
    if (!splasherId) return;

    const fetchSplasherLocation = async () => {
      const { data } = await supabase
        .from('splasher_profiles')
        .select('current_latitude, current_longitude')
        .eq('user_id', splasherId)
        .maybeSingle();

      if (data?.current_latitude && data?.current_longitude) {
        setSplasherLocation({
          lat: Number(data.current_latitude),
          lng: Number(data.current_longitude)
        });
      }
    };

    fetchSplasherLocation();

    // Subscribe to splasher location updates
    const channel = supabase
      .channel(`splasher-location-${splasherId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'splasher_profiles',
          filter: `user_id=eq.${splasherId}`,
        },
        (payload) => {
          const newData = payload.new as any;
          if (newData.current_latitude && newData.current_longitude) {
            setSplasherLocation({
              lat: Number(newData.current_latitude),
              lng: Number(newData.current_longitude)
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [splasherId]);

  const positions: [number, number][] = [
    [customerLocation.lat, customerLocation.lng]
  ];
  
  if (splasherLocation) {
    positions.push([splasherLocation.lat, splasherLocation.lng]);
  }

  const getStatusText = () => {
    switch (status) {
      case 'pending':
        return 'Waiting for a Splasher...';
      case 'accepted':
        return 'Splasher is on the way!';
      case 'in_progress':
        return 'Service in progress';
      default:
        return status;
    }
  };

  return (
    <div className={`rounded-xl overflow-hidden border border-border ${className}`}>
      {/* Status bar */}
      <div className="bg-card px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${
            status === 'pending' ? 'bg-amber-500 animate-pulse' :
            status === 'accepted' ? 'bg-blue-500 animate-pulse' :
            status === 'in_progress' ? 'bg-green-500' : 'bg-muted'
          }`} />
          <span className="text-sm font-medium">{getStatusText()}</span>
        </div>
        {splasherLocation && status === 'accepted' && (
          <span className="text-xs text-muted-foreground">Live tracking</span>
        )}
      </div>
      
      <MapContainer
        center={[customerLocation.lat, customerLocation.lng]}
        zoom={13}
        style={{ height: '100%', width: '100%', minHeight: '250px' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <CenterMap positions={positions} />
        
        {/* Customer location marker */}
        <Marker
          position={[customerLocation.lat, customerLocation.lng]}
          icon={customerIcon}
        >
          <Popup>
            <div className="p-1">
              <p className="font-semibold">Your Location</p>
              <p className="text-sm text-gray-600">{customerLocation.address}</p>
            </div>
          </Popup>
        </Marker>
        
        {/* Splasher location marker */}
        {splasherLocation && (
          <>
            <Marker
              position={[splasherLocation.lat, splasherLocation.lng]}
              icon={carIcon}
            >
              <Popup>
                <div className="p-1">
                  <p className="font-semibold">Your Splasher</p>
                  <p className="text-sm text-gray-600">
                    {status === 'accepted' ? 'On the way' : 'At location'}
                  </p>
                </div>
              </Popup>
            </Marker>
            
            {/* Route line */}
            <Polyline
              positions={[
                [splasherLocation.lat, splasherLocation.lng],
                [customerLocation.lat, customerLocation.lng]
              ]}
              pathOptions={{ 
                color: 'hsl(217, 91%, 60%)', 
                weight: 3, 
                dashArray: '10, 10',
                opacity: 0.7 
              }}
            />
          </>
        )}
      </MapContainer>
    </div>
  );
};

export default SplasherTrackingMap;
