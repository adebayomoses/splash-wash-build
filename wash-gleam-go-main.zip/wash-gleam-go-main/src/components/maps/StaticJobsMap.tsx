import { useMemo, useState, useEffect } from 'react';
import { MapPin, Navigation, X, Car, DollarSign, ExternalLink, Clock, Route, Locate } from 'lucide-react';
import { Button } from '@/components/ui/button';

type Job = {
  id: string;
  location_latitude: number;
  location_longitude: number;
  location_address: string;
  service_type: string;
  vehicle_make: string;
  vehicle_model: string;
  estimated_price: number | null;
  status: string;
};

type StaticJobsMapProps = {
  jobs: Job[];
  activeJobs?: Job[];
  onJobClick?: (job: Job) => void;
  className?: string;
};

type UserLocation = {
  lat: number;
  lng: number;
} | null;

// Haversine formula to calculate distance between two points
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Estimate driving time (rough estimate: avg 25 mph in urban areas)
const estimateDrivingTime = (distanceMiles: number): number => {
  return Math.ceil(distanceMiles / 25 * 60); // minutes
};

const formatDistance = (miles: number): string => {
  if (miles < 0.1) return '< 0.1 mi';
  if (miles < 10) return `${miles.toFixed(1)} mi`;
  return `${Math.round(miles)} mi`;
};

const formatTime = (minutes: number): string => {
  if (minutes < 1) return '< 1 min';
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
};

const StaticJobsMap = ({ jobs, activeJobs = [], onJobClick, className = '' }: StaticJobsMapProps) => {
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [userLocation, setUserLocation] = useState<UserLocation>(null);
  const [locationError, setLocationError] = useState(false);
  const [isLocationUpdating, setIsLocationUpdating] = useState(false);
  const allJobs = useMemo(() => [...jobs, ...activeJobs], [jobs, activeJobs]);

  // Trigger pulse animation on location update
  const triggerLocationPulse = () => {
    setIsLocationUpdating(true);
    setTimeout(() => setIsLocationUpdating(false), 1500);
  };

  // Get and watch user's current location
  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationError(true);
      return;
    }

    // Initial position
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        triggerLocationPulse();
      },
      () => setLocationError(true),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );

    // Watch position for real-time updates
    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLocationError(false);
        triggerLocationPulse();
      },
      () => setLocationError(true),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  // Calculate distances for all jobs
  const jobsWithDistance = useMemo(() => {
    if (!userLocation) return allJobs.map(job => ({ ...job, distance: null, time: null }));
    
    return allJobs.map(job => {
      const distance = calculateDistance(
        userLocation.lat,
        userLocation.lng,
        job.location_latitude,
        job.location_longitude
      );
      const time = estimateDrivingTime(distance);
      return { ...job, distance, time };
    }).sort((a, b) => (a.distance ?? Infinity) - (b.distance ?? Infinity));
  }, [allJobs, userLocation]);

  // Get distance info for selected job
  const selectedJobWithDistance = useMemo(() => {
    if (!selectedJob) return null;
    return jobsWithDistance.find(j => j.id === selectedJob.id) || null;
  }, [selectedJob, jobsWithDistance]);
  
  // Calculate center and bounds
  const mapData = useMemo(() => {
    if (allJobs.length === 0) {
      return { center: { lat: 39.8283, lng: -98.5795 }, zoom: 4 };
    }
    
    const lats = allJobs.map(j => j.location_latitude);
    const lngs = allJobs.map(j => j.location_longitude);
    
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    
    const centerLat = (minLat + maxLat) / 2;
    const centerLng = (minLng + maxLng) / 2;
    
    // Calculate zoom based on bounds spread
    const latSpread = maxLat - minLat;
    const lngSpread = maxLng - minLng;
    const maxSpread = Math.max(latSpread, lngSpread);
    
    let zoom = 12;
    if (maxSpread > 10) zoom = 4;
    else if (maxSpread > 5) zoom = 6;
    else if (maxSpread > 2) zoom = 8;
    else if (maxSpread > 0.5) zoom = 10;
    else if (maxSpread > 0.1) zoom = 12;
    else zoom = 14;
    
    return { center: { lat: centerLat, lng: centerLng }, zoom };
  }, [allJobs]);

  // Generate OpenStreetMap embed URL
  const mapUrl = useMemo(() => {
    const { center } = mapData;
    return `https://www.openstreetmap.org/export/embed.html?bbox=${center.lng - 0.1},${center.lat - 0.1},${center.lng + 0.1},${center.lat + 0.1}&layer=mapnik&marker=${center.lat},${center.lng}`;
  }, [mapData]);

  const activeJobIds = new Set(activeJobs.map(j => j.id));

  const handleJobPillClick = (job: Job) => {
    setSelectedJob(job);
  };

  const handleNavigate = (job: Job) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${job.location_latitude},${job.location_longitude}`;
    window.open(url, '_blank');
  };

  const handleAccept = (job: Job) => {
    onJobClick?.(job);
    setSelectedJob(null);
  };

  return (
    <div className={`rounded-xl overflow-hidden border border-border ${className}`}>
      <div className="relative w-full h-full" style={{ minHeight: '300px' }}>
        {/* Map iframe */}
        <iframe
          title="Jobs Map"
          src={mapUrl}
          className="absolute inset-0 w-full h-full border-0"
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        {/* Location status indicator */}
        <div className="absolute top-2 left-2 z-5">
          <div className={`relative flex items-center gap-1.5 px-2 py-1 rounded-full text-xs transition-all duration-300 ${
            userLocation 
              ? 'bg-green-500/90 text-white' 
              : locationError 
                ? 'bg-muted/90 text-muted-foreground'
                : 'bg-primary/90 text-primary-foreground'
          }`}>
            {/* Pulse ring animation */}
            {isLocationUpdating && userLocation && (
              <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
            )}
            <span className="relative flex items-center gap-1.5">
              <Locate className={`w-3 h-3 ${isLocationUpdating ? 'animate-pulse' : ''}`} />
              {userLocation ? 'Location active' : locationError ? 'Location unavailable' : 'Getting location...'}
            </span>
          </div>
        </div>

        {/* Job Detail Popup */}
        {selectedJob && selectedJobWithDistance && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm z-10">
            <div className="bg-card border border-border rounded-xl shadow-lg max-w-sm w-full mx-4 overflow-hidden">
              {/* Header */}
              <div className={`p-4 ${activeJobIds.has(selectedJob.id) ? 'bg-green-500' : 'bg-primary'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-primary-foreground">
                    <Car className="w-5 h-5" />
                    <span className="font-semibold capitalize">
                      {selectedJob.service_type.replace('_', ' ')}
                    </span>
                  </div>
                  <button 
                    onClick={() => setSelectedJob(null)}
                    className="text-primary-foreground/80 hover:text-primary-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                {activeJobIds.has(selectedJob.id) && (
                  <span className="inline-block mt-2 px-2 py-0.5 bg-white/20 rounded text-xs text-primary-foreground">
                    Active Job
                  </span>
                )}
              </div>

              {/* Content */}
              <div className="p-4 space-y-4">
                {/* Distance & Time */}
                {selectedJobWithDistance.distance !== null && (
                  <div className="flex gap-4 p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Route className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-xs text-muted-foreground">Distance</p>
                        <p className="font-semibold text-foreground">
                          {formatDistance(selectedJobWithDistance.distance)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-xs text-muted-foreground">Est. Time</p>
                        <p className="font-semibold text-foreground">
                          {formatTime(selectedJobWithDistance.time!)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Vehicle */}
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Vehicle</p>
                  <p className="font-semibold text-foreground">
                    {selectedJob.vehicle_make} {selectedJob.vehicle_model}
                  </p>
                </div>

                {/* Location */}
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Location</p>
                  <p className="text-sm text-foreground flex items-start gap-2">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-muted-foreground" />
                    {selectedJob.location_address}
                  </p>
                </div>

                {/* Price */}
                {selectedJob.estimated_price && (
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Estimated Pay</p>
                    <p className="text-2xl font-bold text-primary flex items-center gap-1">
                      <DollarSign className="w-5 h-5" />
                      {selectedJob.estimated_price}
                    </p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleNavigate(selectedJob)}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Directions
                  </Button>
                  {!activeJobIds.has(selectedJob.id) && (
                    <Button 
                      variant="splash" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleAccept(selectedJob)}
                    >
                      Accept Job
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Job locations overlay list */}
        {allJobs.length > 0 && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/95 to-background/0 p-4 pt-8">
            <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
              {jobsWithDistance.slice(0, 6).map(job => {
                const isActive = activeJobIds.has(job.id);
                return (
                  <button
                    key={job.id}
                    onClick={() => handleJobPillClick(job)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                      isActive 
                        ? 'bg-green-500 text-white hover:bg-green-600' 
                        : 'bg-primary text-primary-foreground hover:bg-primary/90'
                    }`}
                  >
                    {isActive ? (
                      <Navigation className="w-3 h-3" />
                    ) : (
                      <MapPin className="w-3 h-3" />
                    )}
                    {job.distance !== null && (
                      <span className="opacity-80">{formatDistance(job.distance)}</span>
                    )}
                    <span className="truncate max-w-[100px]">
                      {job.vehicle_make} {job.vehicle_model}
                    </span>
                    {job.estimated_price && (
                      <span className="font-bold">${job.estimated_price}</span>
                    )}
                  </button>
                );
              })}
              {allJobs.length > 6 && (
                <span className="px-3 py-1.5 rounded-full text-xs bg-muted text-muted-foreground">
                  +{allJobs.length - 6} more
                </span>
              )}
            </div>
          </div>
        )}
        
        {/* Empty state */}
        {allJobs.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
            <div className="text-center text-muted-foreground">
              <MapPin className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No job locations to display</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StaticJobsMap;
