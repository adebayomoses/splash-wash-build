import { useState, useEffect, MutableRefObject } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Car, Droplets, Snowflake, Sparkles, Plus, Clock, CheckCircle, Star } from 'lucide-react';
import NewRequestModal from './NewRequestModal';
import ActiveRequestCard from './ActiveRequestCard';
import RatingModal from './RatingModal';
import { toast } from 'sonner';
import { useRealtimeNotifications } from '@/hooks/useRealtimeNotifications';

type ServiceRequest = {
  id: string;
  service_type: string;
  status: string;
  vehicle_make: string;
  vehicle_model: string;
  location_address: string;
  location_latitude: number;
  location_longitude: number;
  estimated_price: number | null;
  created_at: string;
  splasher_id: string | null;
};

type Rating = {
  request_id: string;
};

interface CustomerDashboardProps {
  onOpenNewRequestRef?: MutableRefObject<(() => void) | null>;
}

const CustomerDashboard = ({ onOpenNewRequestRef }: CustomerDashboardProps) => {
  const { user } = useAuth();
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewRequest, setShowNewRequest] = useState(false);
  const [ratingRequest, setRatingRequest] = useState<ServiceRequest | null>(null);

  // Expose open modal function to parent via ref
  useEffect(() => {
    if (onOpenNewRequestRef) {
      onOpenNewRequestRef.current = () => setShowNewRequest(true);
    }
    return () => {
      if (onOpenNewRequestRef) {
        onOpenNewRequestRef.current = null;
      }
    };
  }, [onOpenNewRequestRef]);

  const fetchRequests = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('service_requests')
      .select('*')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching requests:', error);
      toast.error('Failed to load your requests');
    } else {
      setRequests(data || []);
    }

    // Fetch user's ratings to know which requests have been rated
    const { data: ratingsData } = await supabase
      .from('ratings')
      .select('request_id')
      .eq('rater_id', user.id);

    setRatings(ratingsData || []);
    setLoading(false);
  };

  const hasRated = (requestId: string) => {
    return ratings.some(r => r.request_id === requestId);
  };

  // Real-time notifications for status updates
  useRealtimeNotifications({
    userId: user?.id,
    userRole: 'customer',
    onUpdate: fetchRequests,
  });

  useEffect(() => {
    fetchRequests();
  }, [user]);

  const activeRequests = requests.filter(r => 
    ['pending', 'accepted', 'in_progress'].includes(r.status)
  );
  const completedRequests = requests.filter(r => r.status === 'completed');

  const serviceIcons = {
    car_wash: Droplets,
    detailing: Sparkles,
    de_icing: Snowflake,
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Book a Service</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          {[
            { type: 'car_wash', label: 'Car Wash', icon: Droplets, price: 'From $29' },
            { type: 'detailing', label: 'Full Detailing', icon: Sparkles, price: 'From $199' },
            { type: 'de_icing', label: 'De-Icing', icon: Snowflake, price: 'From $49' },
          ].map(service => (
            <button
              key={service.type}
              onClick={() => setShowNewRequest(true)}
              className="group p-4 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all hover:shadow-lg flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl splash-gradient flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                <service.icon className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-sm">{service.label}</h3>
                <p className="text-xs text-muted-foreground">{service.price}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Active Requests */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Active Requests</h2>
          <Button variant="outline" size="sm" onClick={() => setShowNewRequest(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Request
          </Button>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : activeRequests.length === 0 ? (
          <div className="text-center py-12 bg-muted/30 rounded-2xl">
            <Car className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground mb-4">No active requests</p>
            <Button variant="splash" onClick={() => setShowNewRequest(true)}>
              Book Your First Wash
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {activeRequests.map(request => (
              <ActiveRequestCard key={request.id} request={request} />
            ))}
          </div>
        )}
      </div>

      {/* Completed Requests */}
      {completedRequests.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-6">Recent Completed</h2>
          <div className="space-y-3">
            {completedRequests.slice(0, 5).map(request => {
              const Icon = serviceIcons[request.service_type as keyof typeof serviceIcons] || Car;
              return (
                <div
                  key={request.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-card border border-border"
                >
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                    <Icon className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{request.vehicle_make} {request.vehicle_model}</p>
                    <p className="text-sm text-muted-foreground">{request.location_address}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {hasRated(request.id) ? (
                      <div className="flex items-center gap-1 text-amber-500">
                        <Star className="w-4 h-4 fill-amber-500" />
                        <span className="text-sm font-medium">Rated</span>
                      </div>
                    ) : request.splasher_id ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRatingRequest(request)}
                      >
                        <Star className="w-4 h-4 mr-1" />
                        Rate
                      </Button>
                    ) : (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">Completed</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* New Request Modal */}
      <NewRequestModal
        open={showNewRequest}
        onClose={() => setShowNewRequest(false)}
        onSuccess={() => {
          setShowNewRequest(false);
          fetchRequests();
        }}
      />

      {/* Rating Modal */}
      {ratingRequest && ratingRequest.splasher_id && (
        <RatingModal
          open={!!ratingRequest}
          onClose={() => setRatingRequest(null)}
          onSuccess={() => {
            setRatingRequest(null);
            fetchRequests();
          }}
          requestId={ratingRequest.id}
          splasherId={ratingRequest.splasher_id}
          vehicleInfo={`${ratingRequest.vehicle_make} ${ratingRequest.vehicle_model}`}
        />
      )}
    </div>
  );
};

export default CustomerDashboard;
