import { useState, useEffect } from 'react';
import { Clock, MapPin, MessageSquare, Phone, Droplets, Sparkles, Snowflake, User, ChevronDown, ChevronUp, Star, X, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import SplasherTrackingMap from '@/components/maps/SplasherTrackingMap';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface SplasherInfo {
  full_name: string;
  avatar_url: string | null;
  rating: number;
  total_jobs: number;
  current_latitude: number | null;
  current_longitude: number | null;
}

// Calculate distance between two points using Haversine formula
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Estimate travel time based on distance (average city speed ~30 km/h)
const calculateETA = (distanceKm: number): { minutes: number; text: string } => {
  const avgSpeedKmh = 30;
  const minutes = Math.round((distanceKm / avgSpeedKmh) * 60);
  
  if (minutes < 1) {
    return { minutes: 1, text: 'Less than 1 min' };
  } else if (minutes === 1) {
    return { minutes: 1, text: '1 min away' };
  } else if (minutes < 60) {
    return { minutes, text: `${minutes} mins away` };
  } else {
    const hours = Math.floor(minutes / 60);
    const remainingMins = minutes % 60;
    return { minutes, text: `${hours}h ${remainingMins}m away` };
  }
};

interface ActiveRequestCardProps {
  request: {
    id: string;
    service_type: string;
    status: string;
    vehicle_make: string;
    vehicle_model: string;
    location_address: string;
    location_latitude?: number;
    location_longitude?: number;
    estimated_price: number | null;
    created_at: string;
    splasher_id: string | null;
  };
}

const statusConfig = {
  pending: { label: 'Finding Splasher', color: 'bg-amber-500', animation: 'animate-pulse' },
  accepted: { label: 'Splasher Accepted', color: 'bg-blue-500', animation: '' },
  in_progress: { label: 'In Progress', color: 'bg-green-500', animation: 'animate-pulse' },
};

const serviceIcons = {
  car_wash: Droplets,
  detailing: Sparkles,
  de_icing: Snowflake,
};

const ActiveRequestCard = ({ request }: ActiveRequestCardProps) => {
  const navigate = useNavigate();
  const [showMap, setShowMap] = useState(false);
  const [splasherInfo, setSplasherInfo] = useState<SplasherInfo | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const status = statusConfig[request.status as keyof typeof statusConfig] || statusConfig.pending;
  const Icon = serviceIcons[request.service_type as keyof typeof serviceIcons] || Droplets;
  
  const hasLocation = request.location_latitude && request.location_longitude;
  const canCancel = request.status === 'pending';

  useEffect(() => {
    const fetchSplasherInfo = async () => {
      if (!request.splasher_id) {
        setSplasherInfo(null);
        return;
      }

      // Fetch splasher profile and user profile
      const [{ data: splasherProfile }, { data: userProfile }] = await Promise.all([
        supabase
          .from('splasher_profiles')
          .select('rating, total_jobs, current_latitude, current_longitude')
          .eq('user_id', request.splasher_id)
          .maybeSingle(),
        supabase
          .from('profiles')
          .select('full_name, avatar_url')
          .eq('user_id', request.splasher_id)
          .maybeSingle(),
      ]);

      if (splasherProfile && userProfile) {
        setSplasherInfo({
          full_name: userProfile.full_name,
          avatar_url: userProfile.avatar_url,
          rating: Number(splasherProfile.rating) || 5.0,
          total_jobs: splasherProfile.total_jobs || 0,
          current_latitude: splasherProfile.current_latitude ? Number(splasherProfile.current_latitude) : null,
          current_longitude: splasherProfile.current_longitude ? Number(splasherProfile.current_longitude) : null,
        });
      }
    };

    fetchSplasherInfo();

    // Subscribe to splasher location updates for real-time ETA
    if (request.splasher_id && request.status === 'accepted') {
      const channel = supabase
        .channel(`splasher-location-${request.splasher_id}`)
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'splasher_profiles',
            filter: `user_id=eq.${request.splasher_id}`,
          },
          () => {
            fetchSplasherInfo();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [request.splasher_id, request.status]);

  // Calculate ETA based on Splasher's current location
  const eta = (() => {
    if (!splasherInfo?.current_latitude || !splasherInfo?.current_longitude) {
      return null;
    }
    if (!request.location_latitude || !request.location_longitude) {
      return null;
    }
    
    const distance = calculateDistance(
      splasherInfo.current_latitude,
      splasherInfo.current_longitude,
      request.location_latitude,
      request.location_longitude
    );
    
    return calculateETA(distance);
  })();

  const handleCancel = async () => {
    setCancelling(true);
    
    const { error } = await supabase
      .from('service_requests')
      .update({ status: 'cancelled' })
      .eq('id', request.id)
      .eq('status', 'pending');

    setCancelling(false);

    if (error) {
      toast.error('Failed to cancel request');
    } else {
      toast.success('Request cancelled successfully');
    }
  };

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center gap-3 px-4 py-3 bg-muted/50">
        <div className={`w-2 h-2 rounded-full ${status.color} ${status.animation}`} />
        <span className="text-sm font-medium">{status.label}</span>
        <span className="text-sm text-muted-foreground ml-auto">
          <Clock className="w-4 h-4 inline mr-1" />
          {formatTime(request.created_at)}
        </span>
        {canCancel && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 px-2 text-muted-foreground hover:text-destructive">
                <X className="w-4 h-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancel Request?</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to cancel this {request.service_type.replace('_', ' ')} request for your {request.vehicle_make} {request.vehicle_model}? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Keep Request</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleCancel}
                  disabled={cancelling}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {cancelling ? 'Cancelling...' : 'Yes, Cancel'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-xl splash-gradient flex items-center justify-center flex-shrink-0">
            <Icon className="w-7 h-7 text-primary-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg mb-1">
              {request.vehicle_make} {request.vehicle_model}
            </h3>
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span className="truncate">{request.location_address}</span>
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary">${request.estimated_price}</p>
          </div>
        </div>

        {/* Splasher Info (if assigned) */}
        {request.splasher_id && (
          <div className="mt-4 pt-4 border-t border-border">
            {/* ETA Banner */}
            {eta && request.status === 'accepted' && (
              <div className="flex items-center gap-2 mb-3 p-3 rounded-lg bg-primary/10 text-primary">
                <Navigation className="w-5 h-5" />
                <span className="font-medium">{eta.text}</span>
              </div>
            )}
            
            <div className="flex items-center gap-3">
              {splasherInfo?.avatar_url ? (
                <img
                  src={splasherInfo.avatar_url}
                  alt={splasherInfo.full_name}
                  className="w-12 h-12 rounded-full object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                  <User className="w-6 h-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <p className="font-medium">{splasherInfo?.full_name || 'Your Splasher'}</p>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    {splasherInfo?.rating.toFixed(1) || '5.0'}
                  </span>
                  <span>•</span>
                  <span>{splasherInfo?.total_jobs || 0} jobs</span>
                  {!eta && request.status === 'accepted' && (
                    <>
                      <span>•</span>
                      <span className="text-primary">On the way</span>
                    </>
                  )}
                </div>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button variant="outline" size="icon" className="w-10 h-10" onClick={() => navigate(`/chat/${request.id}`)}>
                  <MessageSquare className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" className="w-10 h-10">
                  <Phone className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Map Toggle Button */}
        {hasLocation && (
          <div className="mt-4 pt-4 border-t border-border">
            <Button 
              variant="outline" 
              className="w-full justify-between"
              onClick={() => setShowMap(!showMap)}
            >
              <span className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                {request.splasher_id ? 'Track Splasher' : 'View Location'}
              </span>
              {showMap ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
          </div>
        )}
      </div>

      {/* Tracking Map */}
      {showMap && hasLocation && (
        <SplasherTrackingMap
          requestId={request.id}
          splasherId={request.splasher_id}
          customerLocation={{
            lat: Number(request.location_latitude),
            lng: Number(request.location_longitude),
            address: request.location_address
          }}
          status={request.status}
          className="h-[250px] rounded-none border-t"
        />
      )}
    </div>
  );
};

export default ActiveRequestCard;
