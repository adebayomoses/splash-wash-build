import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import AddressAutocomplete from '@/components/ui/address-autocomplete';
import { ImageUpload } from '@/components/ui/image-upload';
import { Droplets, Sparkles, Snowflake, Car, ArrowRight, MapPin, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface NewRequestModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const services = [
  { value: 'car_wash', label: 'Car Wash', icon: Droplets, price: 29 },
  { value: 'detailing', label: 'Full Detailing', icon: Sparkles, price: 199 },
  { value: 'de_icing', label: 'De-Icing', icon: Snowflake, price: 49 },
];

const NewRequestModal = ({ open, onClose, onSuccess }: NewRequestModalProps) => {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [formData, setFormData] = useState({
    serviceType: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleColor: '',
    vehicleImageUrl: '',
    locationAddress: '',
    locationLat: 40.7128,
    locationLng: -74.006,
    notes: '',
  });

  const handleChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const resetForm = () => {
    setStep(1);
    setFormData({
      serviceType: '',
      vehicleMake: '',
      vehicleModel: '',
      vehicleYear: '',
      vehicleColor: '',
      vehicleImageUrl: '',
      locationAddress: '',
      locationLat: 40.7128,
      locationLng: -74.006,
      notes: '',
    });
  };

  const handleImageUpload = async (file: File): Promise<string | null> => {
    if (!user) return null;
    
    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('car-images')
      .upload(fileName, file);
    
    if (uploadError) {
      toast.error('Failed to upload image');
      return null;
    }
    
    const { data: { publicUrl } } = supabase.storage
      .from('car-images')
      .getPublicUrl(fileName);
    
    return publicUrl;
  };

  const handleAddressChange = (address: string, lat?: number, lng?: number) => {
    setFormData(prev => ({
      ...prev,
      locationAddress: address,
      ...(lat !== undefined && { locationLat: lat }),
      ...(lng !== undefined && { locationLng: lng }),
    }));
  };

  const useCurrentLocation = async () => {
    if (!navigator.geolocation) {
      toast.error('Geolocation is not supported by your browser');
      return;
    }

    setLocationLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        // Reverse geocoding using OpenStreetMap Nominatim (free, no API key)
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`
          );
          const data = await response.json();
          
          const address = data.display_name || `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          
          setFormData(prev => ({
            ...prev,
            locationAddress: address,
            locationLat: latitude,
            locationLng: longitude,
          }));
          
          toast.success('Location detected successfully');
        } catch (error) {
          // Fallback to coordinates if reverse geocoding fails
          setFormData(prev => ({
            ...prev,
            locationAddress: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
            locationLat: latitude,
            locationLng: longitude,
          }));
          toast.success('Location detected (coordinates only)');
        }
        
        setLocationLoading(false);
      },
      (error) => {
        setLocationLoading(false);
        if (error.code === error.PERMISSION_DENIED) {
          toast.error('Location access denied. Please enable location services.');
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          toast.error('Location unavailable. Please try again.');
        } else {
          toast.error('Failed to get location. Please enter manually.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      }
    );
  };

  const handleSubmit = async () => {
    if (!user) return;

    setLoading(true);
    const selectedService = services.find(s => s.value === formData.serviceType);

    const { error } = await supabase.from('service_requests').insert({
      customer_id: user.id,
      service_type: formData.serviceType as 'car_wash' | 'detailing' | 'de_icing',
      vehicle_make: formData.vehicleMake,
      vehicle_model: formData.vehicleModel,
      vehicle_year: formData.vehicleYear,
      vehicle_color: formData.vehicleColor,
      vehicle_image_url: formData.vehicleImageUrl || null,
      location_address: formData.locationAddress,
      location_latitude: formData.locationLat,
      location_longitude: formData.locationLng,
      notes: formData.notes,
      estimated_price: selectedService?.price || 0,
    });

    setLoading(false);

    if (error) {
      console.error('Error creating request:', error);
      toast.error('Failed to create request');
    } else {
      setStep(4); // Go to searching screen
    }
  };

  const handleHideSearch = () => {
    toast.success('Request submitted! We\'ll notify you when a Splasher accepts.');
    onSuccess();
    resetForm();
  };

  const selectedService = services.find(s => s.value === formData.serviceType);

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen && step !== 4) {
        onClose();
      } else if (!isOpen && step === 4) {
        handleHideSearch();
      }
    }}>
      <DialogContent className="sm:max-w-md">
        {step !== 4 && (
          <DialogHeader>
            <DialogTitle>
              {step === 1 && 'Choose Service'}
              {step === 2 && 'Vehicle Details'}
              {step === 3 && 'Location & Notes'}
            </DialogTitle>
            <DialogDescription className="sr-only">
              {step === 1 && 'Select a service type for your car'}
              {step === 2 && 'Enter your vehicle information'}
              {step === 3 && 'Provide your location and any special notes'}
            </DialogDescription>
          </DialogHeader>
        )}

        {step === 1 && (
          <div className="space-y-4">
            {services.map(service => (
              <button
                key={service.value}
                onClick={() => {
                  handleChange('serviceType', service.value);
                  setStep(2);
                }}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all ${
                  formData.serviceType === service.value
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <div className="w-12 h-12 rounded-xl splash-gradient flex items-center justify-center">
                  <service.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{service.label}</p>
                  <p className="text-sm text-muted-foreground">From ${service.price}</p>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground" />
              </button>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Make</Label>
                <Input
                  placeholder="Toyota"
                  value={formData.vehicleMake}
                  onChange={e => handleChange('vehicleMake', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Model</Label>
                <Input
                  placeholder="Camry"
                  value={formData.vehicleModel}
                  onChange={e => handleChange('vehicleModel', e.target.value)}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Year</Label>
                <Input
                  placeholder="2023"
                  value={formData.vehicleYear}
                  onChange={e => handleChange('vehicleYear', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Color</Label>
                <Input
                  placeholder="Silver"
                  value={formData.vehicleColor}
                  onChange={e => handleChange('vehicleColor', e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Car Photo (Optional)</Label>
              <ImageUpload
                value={formData.vehicleImageUrl}
                onChange={(url) => handleChange('vehicleImageUrl', url || '')}
                onFileSelect={handleImageUpload}
              />
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                Back
              </Button>
              <Button
                variant="splash"
                onClick={() => setStep(3)}
                className="flex-1"
                disabled={!formData.vehicleMake || !formData.vehicleModel || !formData.vehicleYear}
              >
                Continue
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Location Address</Label>
              <AddressAutocomplete
                value={formData.locationAddress}
                onChange={handleAddressChange}
                placeholder="123 Main St, City, State"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={useCurrentLocation}
                disabled={locationLoading}
                className="w-full mt-2"
              >
                {locationLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Detecting location...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4 mr-2" />
                    Use Current Location
                  </>
                )}
              </Button>
            </div>
            <div className="space-y-2">
              <Label>Special Notes (Optional)</Label>
              <Textarea
                placeholder="Any special instructions for the Splasher..."
                value={formData.notes}
                onChange={e => handleChange('notes', e.target.value)}
                rows={3}
              />
            </div>

            {/* Summary */}
            <div className="p-4 rounded-xl bg-muted/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-muted-foreground">Service</span>
                <span className="font-medium">{selectedService?.label}</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-muted-foreground">Vehicle</span>
                <span className="font-medium">
                  {formData.vehicleMake} {formData.vehicleModel}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-border">
                <span className="font-semibold">Estimated Price</span>
                <span className="text-xl font-bold text-primary">${selectedService?.price}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
                Back
              </Button>
              <Button
                variant="splash"
                onClick={handleSubmit}
                className="flex-1"
                disabled={loading || !formData.locationAddress}
              >
                {loading ? 'Submitting...' : 'Request Splasher'}
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Radar Searching Animation */}
        {step === 4 && (
          <div className="flex flex-col items-center justify-center py-8 space-y-6">
            {/* Radar Animation */}
            <div className="relative w-48 h-48 flex items-center justify-center">
              {/* Outer ring - slowest */}
              <div className="absolute inset-0 rounded-full border-2 border-primary/20 animate-[radar-ping_3s_ease-out_infinite]" />
              {/* Middle ring */}
              <div className="absolute inset-4 rounded-full border-2 border-primary/30 animate-[radar-ping_3s_ease-out_infinite_0.5s]" />
              {/* Inner ring */}
              <div className="absolute inset-8 rounded-full border-2 border-primary/40 animate-[radar-ping_3s_ease-out_infinite_1s]" />
              {/* Solid inner circle */}
              <div className="absolute inset-12 rounded-full bg-primary/10 animate-pulse" />
              
              {/* Center icon */}
              <div className="relative z-10 w-16 h-16 rounded-full splash-gradient flex items-center justify-center shadow-lg">
                <Car className="w-8 h-8 text-primary-foreground" />
              </div>
            </div>

            {/* Text */}
            <div className="text-center space-y-2">
              <h3 className="text-xl font-semibold">Finding Splashers near you</h3>
              <p className="text-muted-foreground flex items-center justify-center gap-1">
                Searching
                <span className="inline-flex">
                  <span className="animate-[bounce_1s_infinite_0ms]">.</span>
                  <span className="animate-[bounce_1s_infinite_150ms]">.</span>
                  <span className="animate-[bounce_1s_infinite_300ms]">.</span>
                </span>
              </p>
            </div>

            {/* Hide Button */}
            <Button
              variant="outline"
              onClick={handleHideSearch}
              className="mt-4"
            >
              Hide & Continue
            </Button>
            <p className="text-xs text-muted-foreground text-center max-w-[250px]">
              You'll be notified when a Splasher accepts your request
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default NewRequestModal;
