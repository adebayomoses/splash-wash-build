import { Home, Plus, Clock, User, Briefcase, DollarSign } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface BottomNavigationProps {
  viewMode: 'customer' | 'splasher';
  onNewRequest?: () => void;
}

interface NavItem {
  icon: React.ElementType;
  label: string;
  action: () => void;
  isActive?: boolean;
}

const BottomNavigation = ({ viewMode, onNewRequest }: BottomNavigationProps) => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;
  const isDashboard = location.pathname === '/dashboard';

  const customerItems: NavItem[] = [
    {
      icon: Home,
      label: 'Home',
      action: () => navigate('/dashboard'),
      isActive: isDashboard,
    },
    {
      icon: Plus,
      label: 'Request',
      action: () => onNewRequest?.(),
      isActive: false,
    },
    {
      icon: Clock,
      label: 'History',
      action: () => navigate('/history'),
      isActive: isActive('/history'),
    },
    {
      icon: User,
      label: 'Profile',
      action: () => navigate('/profile'),
      isActive: isActive('/profile'),
    },
  ];

  const splasherItems: NavItem[] = [
    {
      icon: Home,
      label: 'Home',
      action: () => navigate('/dashboard'),
      isActive: isDashboard,
    },
    {
      icon: Briefcase,
      label: 'Requests',
      action: () => navigate('/dashboard'),
      isActive: false,
    },
    {
      icon: DollarSign,
      label: 'Earnings',
      action: () => navigate('/earnings'),
      isActive: isActive('/earnings'),
    },
    {
      icon: User,
      label: 'Profile',
      action: () => navigate('/profile'),
      isActive: isActive('/profile'),
    },
  ];

  const items = viewMode === 'customer' ? customerItems : splasherItems;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-t border-border safe-area-bottom">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-4">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              onClick={item.action}
              className={cn(
                'flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors',
                item.isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNavigation;
