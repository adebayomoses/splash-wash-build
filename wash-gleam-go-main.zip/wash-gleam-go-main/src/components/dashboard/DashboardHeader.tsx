import { Droplets, Car, Briefcase } from 'lucide-react';

interface DashboardHeaderProps {
  viewMode: 'customer' | 'splasher';
  setViewMode: (mode: 'customer' | 'splasher') => void;
}

const DashboardHeader = ({ viewMode, setViewMode }: DashboardHeaderProps) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <Droplets className="w-6 h-6 text-primary" />
            <span className="text-base font-bold splash-gradient-text">Splash</span>
          </a>

          {/* Compact Mode Toggle */}
          <div className="flex items-center gap-1 bg-muted rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('customer')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'customer'
                  ? 'bg-background shadow-sm text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Car className="w-4 h-4" />
              <span className="hidden sm:inline">Customer</span>
            </button>
            <button
              onClick={() => setViewMode('splasher')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                viewMode === 'splasher'
                  ? 'bg-background shadow-sm text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span className="hidden sm:inline">Splasher</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;
