import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { useSoundNotifications } from '@/hooks/useSoundNotifications';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Briefcase, MapPin, DollarSign, Star, Clock, CheckCircle, XCircle, Play, ArrowRight, Map, Navigation, Car } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import LazyJobsMap from '@/components/maps/LazyJobsMap';
import { useSplasherLocationTracking } from '@/hooks/useSplasherLocationTracking';
import { useRealtimeNotifications } from '@/hooks/useRealtimeNotifications';
import { playNotificationSound } from '@/utils/notificationSound';
import JobDetailsModal from './JobDetailsModal';

type ServiceRequest = {
  id: string;
  service_type: 'car_wash' | 'detailing' | 'de_icing';
  status: string;
  vehicle_make: string;
  vehicle_model: string;
  vehicle_year: string;
  vehicle_color: string | null;
  vehicle_image_url: string | null;
  location_address: string;
  location_latitude: number;
  location_longitude: number;
  estimated_price: number | null;
  created_at: string;
  notes: string | null;
};

const SplasherDashboard = () => {
  const { user } = useAuth();
  const { isSplasher } = useUserRole();
  const { soundEnabled } = useSoundNotifications();
  const navigate = useNavigate();
  const [isAvailable, setIsAvailable] = useState(false);
  const [pendingRequests, setPendingRequests] = useState<ServiceRequest[]>([]);
  const [myJobs, setMyJobs] = useState<ServiceRequest[]>([]);
  const [stats, setStats] = useState({ totalJobs: 0, rating: 5.0, earnings: 0 });
  const [loading, setLoading] = useState(true);
  const [showMap, setShowMap] = useState(true);
  const [selectedJob, setSelectedJob] = useState<ServiceRequest | null>(null);
  const [isAccepting, setIsAccepting] = useState(false);
  // Track previous job IDs to detect new jobs
  const previousJobIdsRef = useRef<Set<string>>(new Set());
  const isInitialLoadRef = useRef(true);

  // GPS tracking for active jobs
  const hasActiveJob = myJobs.some(job => job.status === 'in_progress' || job.status === 'accepted');
  const { isTracking } = useSplasherLocationTracking({
    userId: user?.id,
    hasActiveJob,
    updateIntervalMs: 10000, // Update every 10 seconds
  });

  const fetchData = async () => {
    if (!user || !isSplasher) return;

    // Fetch pending requests
    const { data: pending } = await supabase
      .from('service_requests')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    const newPending = pending || [];
    
    // Check for new jobs (only after initial load)
    if (!isInitialLoadRef.current && newPending.length > 0) {
      const currentIds = new Set(newPending.map(j => j.id));
      const newJobs = newPending.filter(job => !previousJobIdsRef.current.has(job.id));
      
      if (newJobs.length > 0) {
        // Play notification sound only if enabled
        if (soundEnabled) {
          playNotificationSound('newJob');
        }
        
        // Show toast notification
        toast.success(`${newJobs.length} new job${newJobs.length > 1 ? 's' : ''} available nearby!`, {
          description: newJobs[0].vehicle_make + ' ' + newJobs[0].vehicle_model,
          duration: 5000,
        });
      }
      
      previousJobIdsRef.current = currentIds;
    } else if (isInitialLoadRef.current) {
      // Set initial job IDs without notification
      previousJobIdsRef.current = new Set(newPending.map(j => j.id));
      isInitialLoadRef.current = false;
    }

    setPendingRequests(newPending);

    // Fetch my accepted jobs
    const { data: jobs } = await supabase
      .from('service_requests')
      .select('*')
      .eq('splasher_id', user.id)
      .in('status', ['accepted', 'in_progress'])
      .order('created_at', { ascending: false });

    setMyJobs(jobs || []);

    // Fetch splasher profile
    const { data: profile } = await supabase
      .from('splasher_profiles')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (profile) {
      setIsAvailable(profile.is_available);
      setStats({
        totalJobs: profile.total_jobs || 0,
        rating: Number(profile.rating) || 5.0,
        earnings: (profile.total_jobs || 0) * 25, // Simplified earnings calc
      });
    }

    setLoading(false);
  };

  // Real-time notifications for new jobs
  useRealtimeNotifications({
    userId: user?.id,
    userRole: 'splasher',
    onUpdate: fetchData,
  });

  useEffect(() => {
    fetchData();
  }, [user, isSplasher]);

  const toggleAvailability = async () => {
    if (!user) return;

    const { error } = await supabase
      .from('splasher_profiles')
      .update({ is_available: !isAvailable })
      .eq('user_id', user.id);

    if (error) {
      toast.error('Failed to update availability');
    } else {
      setIsAvailable(!isAvailable);
      toast.success(isAvailable ? 'You are now offline' : 'You are now available for jobs');
    }
  };

  const acceptJob = async (requestId: string) => {
    if (!user) return;

    setIsAccepting(true);
    const { error } = await supabase
      .from('service_requests')
      .update({ splasher_id: user.id, status: 'accepted' })
      .eq('id', requestId)
      .eq('status', 'pending');

    setIsAccepting(false);
    if (error) {
      toast.error('Failed to accept job');
    } else {
      toast.success('Job accepted!');
      setSelectedJob(null);
      fetchData();
    }
  };

  const updateJobStatus = async (requestId: string, status: 'in_progress' | 'completed') => {
    const updates: Record<string, any> = { status };
    if (status === 'in_progress') updates.started_at = new Date().toISOString();
    if (status === 'completed') updates.completed_at = new Date().toISOString();

    const { error } = await supabase
      .from('service_requests')
      .update(updates)
      .eq('id', requestId);

    if (error) {
      toast.error('Failed to update job');
    } else {
      toast.success(status === 'completed' ? 'Job completed!' : 'Job started!');
      fetchData();
    }
  };

  // If not a Splasher, show apply prompt
  if (!isSplasher) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full splash-gradient flex items-center justify-center">
            <Briefcase className="w-10 h-10 text-primary-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Become a Splasher</h2>
          <p className="text-muted-foreground mb-6">
            Join our team of professional car care experts and earn money on your own schedule.
          </p>
          <Button variant="splash" size="lg" onClick={() => navigate('/become-splasher')}>
            Apply Now
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Stats Header */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 mb-8">
        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground text-sm">Status</span>
            <Switch checked={isAvailable} onCheckedChange={toggleAvailability} />
          </div>
          <p className={`font-bold ${isAvailable ? 'text-green-600' : 'text-muted-foreground'}`}>
            {isAvailable ? 'Available' : 'Offline'}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border">
          <p className="text-muted-foreground text-sm mb-2">Total Jobs</p>
          <p className="text-2xl font-bold">{stats.totalJobs}</p>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border">
          <p className="text-muted-foreground text-sm mb-2">Rating</p>
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span className="text-2xl font-bold">{stats.rating.toFixed(1)}</span>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border">
          <p className="text-muted-foreground text-sm mb-2">GPS Tracking</p>
          <div className="flex items-center gap-2">
            <Navigation className={`w-5 h-5 ${isTracking ? 'text-green-500 animate-pulse' : 'text-muted-foreground'}`} />
            <span className={`font-bold ${isTracking ? 'text-green-600' : 'text-muted-foreground'}`}>
              {isTracking ? 'Active' : 'Inactive'}
            </span>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-card border border-border">
          <p className="text-muted-foreground text-sm mb-2">Earnings</p>
          <p className="text-2xl font-bold text-primary">${stats.earnings}</p>
        </div>
      </div>

      {/* Active Jobs */}
      {myJobs.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Your Active Jobs</h2>
          <div className="space-y-4">
            {myJobs.map(job => (
              <div key={job.id} className="p-4 rounded-xl bg-card border-2 border-primary">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-semibold">
                      {job.vehicle_make} {job.vehicle_model}
                      {job.vehicle_color && ` (${job.vehicle_color})`}
                    </p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {job.location_address}
                    </p>
                  </div>
                  <p className="text-xl font-bold text-primary">${job.estimated_price}</p>
                </div>
                {job.notes && (
                  <p className="text-sm text-muted-foreground mb-3 p-2 bg-muted rounded">
                    Note: {job.notes}
                  </p>
                )}
                <div className="flex gap-2">
                  {job.status === 'accepted' && (
                    <Button
                      variant="splash"
                      onClick={() => updateJobStatus(job.id, 'in_progress')}
                      className="flex-1"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Job
                    </Button>
                  )}
                  {job.status === 'in_progress' && (
                    <Button
                      variant="splash"
                      onClick={() => updateJobStatus(job.id, 'completed')}
                      className="flex-1"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Complete Job
                    </Button>
                  )}
                  <Button variant="outline" onClick={() => navigate(`/chat/${job.id}`)}>
                    Chat
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Jobs Map */}
      {(pendingRequests.length > 0 || myJobs.length > 0) && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Map className="w-5 h-5" />
              Jobs Map
            </h2>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowMap(!showMap)}
            >
              {showMap ? 'Hide Map' : 'Show Map'}
            </Button>
          </div>
          {showMap && (
            <LazyJobsMap
              jobs={pendingRequests.map(r => ({
                ...r,
                location_latitude: Number(r.location_latitude),
                location_longitude: Number(r.location_longitude)
              }))}
              activeJobs={myJobs.map(j => ({
                ...j,
                location_latitude: Number(j.location_latitude),
                location_longitude: Number(j.location_longitude)
              }))}
              className="h-[350px]"
            />
          )}
        </div>
      )}

      {/* Available Requests */}
      <div>
        <h2 className="text-xl font-bold mb-4">Available Jobs</h2>
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : pendingRequests.length === 0 ? (
          <div className="text-center py-12 bg-muted/30 rounded-2xl">
            <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">No available jobs right now</p>
            <p className="text-sm text-muted-foreground mt-1">
              {isAvailable ? 'Check back soon!' : 'Go online to see available jobs'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {pendingRequests.map(request => (
              <div key={request.id} className="p-3 sm:p-4 rounded-xl bg-card border border-border">
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                  {/* Car Image */}
                  {request.vehicle_image_url ? (
                    <div className="w-full sm:w-24 h-32 sm:h-24 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={request.vehicle_image_url}
                        alt={`${request.vehicle_make} ${request.vehicle_model}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-full sm:w-24 h-32 sm:h-24 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                      <Car className="w-8 h-8 text-muted-foreground" />
                    </div>
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold capitalize">
                          {request.service_type.replace('_', ' ')}
                        </p>
                        <p className="text-sm text-muted-foreground truncate">
                          {request.vehicle_make} {request.vehicle_model}
                          {request.vehicle_color && ` • ${request.vehicle_color}`}
                        </p>
                      </div>
                      <p className="text-lg sm:text-xl font-bold text-primary flex-shrink-0">${request.estimated_price}</p>
                    </div>
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mb-3 truncate">
                      <MapPin className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate">{request.location_address}</span>
                    </p>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Button variant="splash" onClick={() => acceptJob(request.id)} className="flex-1 min-h-[44px]">
                        Accept Job
                      </Button>
                      <Button 
                        variant="outline" 
                        className="min-h-[44px]"
                        onClick={() => setSelectedJob(request)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Job Details Modal */}
      <JobDetailsModal
        job={selectedJob}
        isOpen={!!selectedJob}
        onClose={() => setSelectedJob(null)}
        onAccept={acceptJob}
        isAccepting={isAccepting}
      />
    </div>
  );
};

export default SplasherDashboard;
