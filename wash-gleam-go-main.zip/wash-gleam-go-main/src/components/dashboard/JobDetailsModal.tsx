import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Car, MapPin, Clock, DollarSign, FileText, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface ServiceRequest {
  id: string;
  service_type: 'car_wash' | 'detailing' | 'de_icing';
  vehicle_make: string;
  vehicle_model: string;
  vehicle_year: string;
  vehicle_color: string | null;
  vehicle_image_url: string | null;
  location_address: string;
  location_latitude: number;
  location_longitude: number;
  notes: string | null;
  estimated_price: number | null;
  created_at: string;
  status: string;
}

interface JobDetailsModalProps {
  job: ServiceRequest | null;
  isOpen: boolean;
  onClose: () => void;
  onAccept: (jobId: string) => void;
  isAccepting?: boolean;
}

const serviceTypeLabels: Record<string, string> = {
  car_wash: 'Car Wash',
  detailing: 'Detailing',
  de_icing: 'De-icing',
};

const serviceTypeColors: Record<string, string> = {
  car_wash: 'bg-primary/10 text-primary',
  detailing: 'bg-secondary/50 text-secondary-foreground',
  de_icing: 'bg-accent/50 text-accent-foreground',
};

const JobDetailsModal = ({ job, isOpen, onClose, onAccept, isAccepting }: JobDetailsModalProps) => {
  if (!job) return null;

  const openInMaps = () => {
    const url = `https://www.google.com/maps/search/?api=1&query=${job.location_latitude},${job.location_longitude}`;
    window.open(url, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Job Details</DialogTitle>
          <DialogDescription className="sr-only">
            View complete details for this service request
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Vehicle Image */}
          {job.vehicle_image_url && (
            <div className="w-full h-48 rounded-lg overflow-hidden">
              <img
                src={job.vehicle_image_url}
                alt={`${job.vehicle_make} ${job.vehicle_model}`}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Service Type Badge */}
          <div className="flex items-center justify-between">
            <Badge className={serviceTypeColors[job.service_type]}>
              {serviceTypeLabels[job.service_type]}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {formatDistanceToNow(new Date(job.created_at), { addSuffix: true })}
            </span>
          </div>

          {/* Vehicle Info */}
          <div className="p-4 bg-muted/50 rounded-lg space-y-2">
            <div className="flex items-center gap-2 text-foreground font-medium">
              <Car className="w-5 h-5 text-primary" />
              <span>{job.vehicle_year} {job.vehicle_make} {job.vehicle_model}</span>
            </div>
            {job.vehicle_color && (
              <p className="text-sm text-muted-foreground ml-7">
                Color: {job.vehicle_color}
              </p>
            )}
          </div>

          {/* Location */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-start gap-2">
              <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-foreground">{job.location_address}</p>
                <Button
                  variant="link"
                  className="p-0 h-auto text-primary text-sm"
                  onClick={openInMaps}
                >
                  Open in Maps <ExternalLink className="w-3 h-3 ml-1" />
                </Button>
              </div>
            </div>
          </div>

          {/* Notes */}
          {job.notes && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="flex items-start gap-2">
                <FileText className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground mb-1">Customer Notes</p>
                  <p className="text-sm text-muted-foreground">{job.notes}</p>
                </div>
              </div>
            </div>
          )}

          {/* Price */}
          <div className="p-4 bg-primary/10 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-foreground font-medium flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-primary" />
                Estimated Price
              </span>
              <span className="text-2xl font-bold text-primary">
                ${job.estimated_price?.toFixed(2) || '0.00'}
              </span>
            </div>
          </div>

          {/* Accept Button */}
          <Button
            className="w-full min-h-[44px]"
            onClick={() => onAccept(job.id)}
            disabled={isAccepting}
          >
            {isAccepting ? 'Accepting...' : 'Accept Job'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default JobDetailsModal;
