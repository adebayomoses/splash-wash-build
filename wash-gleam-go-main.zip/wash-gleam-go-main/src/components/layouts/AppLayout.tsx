import { ReactNode } from 'react';
import { useUserRole } from '@/hooks/useUserRole';
import { useSoundNotifications } from '@/hooks/useSoundNotifications';
import { useViewMode } from '@/contexts/ViewModeContext';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import BottomNavigation from '@/components/dashboard/BottomNavigation';
import { Loader2 } from 'lucide-react';

interface AppLayoutProps {
  children: ReactNode;
  showHeader?: boolean;
}

const AppLayout = ({ children, showHeader = true }: AppLayoutProps) => {
  const { isSplasher, loading: rolesLoading } = useUserRole();
  const { soundEnabled, toggleSound } = useSoundNotifications();
  const { viewMode, setViewMode, triggerNewRequest } = useViewMode();

  if (rolesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {showHeader && (
        <DashboardHeader
          viewMode={viewMode}
          setViewMode={setViewMode}
        />
      )}
      <main className={showHeader ? 'pt-16' : ''}>
        {children}
      </main>
      <BottomNavigation
        viewMode={viewMode}
        onNewRequest={triggerNewRequest}
      />
    </div>
  );
};

export default AppLayout;
