import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Droplets, Sparkles, Snowflake, ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import Header from '@/components/Header';

const BecomeSplasher = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    vehicleType: '',
    vehicleYear: '',
    licenseNumber: '',
    experienceYears: '',
    services: [] as string[],
  });

  const handleChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const toggleService = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service],
    }));
  };

  const handleSubmit = async () => {
    if (!user) {
      toast.error('Please sign in first');
      navigate('/auth');
      return;
    }

    setLoading(true);

    const { error } = await supabase.from('splasher_applications').insert({
      user_id: user.id,
      vehicle_type: formData.vehicleType,
      vehicle_year: formData.vehicleYear,
      license_number: formData.licenseNumber,
      experience_years: parseInt(formData.experienceYears) || 0,
      services_offered: formData.services as ('car_wash' | 'detailing' | 'de_icing')[],
    });

    if (error) {
      if (error.code === '23505') {
        toast.error('You have already submitted an application');
      } else {
        console.error('Error submitting application:', error);
        toast.error('Failed to submit application');
      }
    } else {
      setSubmitted(true);
      // Add splasher role and profile (auto-approve for demo)
      await supabase.from('user_roles').insert({
        user_id: user.id,
        role: 'splasher',
      });
      await supabase.from('splasher_profiles').insert({
        user_id: user.id,
        services_offered: formData.services as ('car_wash' | 'detailing' | 'de_icing')[],
      });
      toast.success('Application approved! You are now a Splasher!');
    }
    setLoading(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-32 pb-16 px-4">
          <div className="max-w-md mx-auto text-center">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold mb-4">Welcome to Splash!</h1>
            <p className="text-muted-foreground mb-8">
              Your application has been approved. You can now start accepting jobs and earning money!
            </p>
            <Button variant="splash" size="lg" onClick={() => navigate('/dashboard')}>
              Go to Dashboard
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-lg mx-auto">
          {/* Progress */}
          <div className="flex items-center gap-2 mb-8">
            {[1, 2, 3].map(s => (
              <div
                key={s}
                className={`flex-1 h-2 rounded-full transition-colors ${
                  s <= step ? 'splash-gradient' : 'bg-muted'
                }`}
              />
            ))}
          </div>

          <div className="bg-card rounded-2xl border border-border p-6">
            {step === 1 && (
              <>
                <h2 className="text-2xl font-bold mb-2">Tell us about your vehicle</h2>
                <p className="text-muted-foreground mb-6">
                  We need some information about your vehicle for our records.
                </p>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Vehicle Type</Label>
                    <Input
                      placeholder="e.g., SUV, Sedan, Van"
                      value={formData.vehicleType}
                      onChange={e => handleChange('vehicleType', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Vehicle Year</Label>
                    <Input
                      placeholder="e.g., 2022"
                      value={formData.vehicleYear}
                      onChange={e => handleChange('vehicleYear', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Driver's License Number</Label>
                    <Input
                      placeholder="Your license number"
                      value={formData.licenseNumber}
                      onChange={e => handleChange('licenseNumber', e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={() => navigate(-1)} className="flex-1">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    variant="splash"
                    onClick={() => setStep(2)}
                    className="flex-1"
                    disabled={!formData.vehicleType || !formData.vehicleYear || !formData.licenseNumber}
                  >
                    Continue
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <h2 className="text-2xl font-bold mb-2">Your Experience</h2>
                <p className="text-muted-foreground mb-6">
                  How long have you been doing car care services?
                </p>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Years of Experience</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={formData.experienceYears}
                      onChange={e => handleChange('experienceYears', e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button variant="splash" onClick={() => setStep(3)} className="flex-1">
                    Continue
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <h2 className="text-2xl font-bold mb-2">Services You'll Offer</h2>
                <p className="text-muted-foreground mb-6">
                  Select the services you want to provide to customers.
                </p>
                <div className="space-y-4">
                  {[
                    { value: 'car_wash', label: 'Car Wash', icon: Droplets, desc: 'Basic to premium car washing' },
                    { value: 'detailing', label: 'Full Detailing', icon: Sparkles, desc: 'Complete interior and exterior detailing' },
                    { value: 'de_icing', label: 'De-Icing', icon: Snowflake, desc: 'Winter ice and snow removal' },
                  ].map(service => (
                    <div
                      key={service.value}
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        formData.services.includes(service.value)
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => toggleService(service.value)}
                    >
                      <Checkbox checked={formData.services.includes(service.value)} />
                      <div className="w-10 h-10 rounded-lg splash-gradient flex items-center justify-center">
                        <service.icon className="w-5 h-5 text-primary-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">{service.label}</p>
                        <p className="text-sm text-muted-foreground">{service.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    variant="splash"
                    onClick={handleSubmit}
                    className="flex-1"
                    disabled={loading || formData.services.length === 0}
                  >
                    {loading ? 'Submitting...' : 'Submit Application'}
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BecomeSplasher;
