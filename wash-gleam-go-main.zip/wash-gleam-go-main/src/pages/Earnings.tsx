import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingUp, Calendar, Loader2 } from 'lucide-react';
import { format, startOfWeek, startOfMonth, endOfWeek, endOfMonth } from 'date-fns';
import AppLayout from '@/components/layouts/AppLayout';

interface EarningsData {
  totalEarnings: number;
  weeklyEarnings: number;
  monthlyEarnings: number;
  completedJobs: number;
  recentJobs: Array<{
    id: string;
    service_type: string;
    final_price: number;
    completed_at: string;
  }>;
}

const Earnings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [earnings, setEarnings] = useState<EarningsData>({
    totalEarnings: 0,
    weeklyEarnings: 0,
    monthlyEarnings: 0,
    completedJobs: 0,
    recentJobs: [],
  });

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchEarnings();
  }, [user, navigate]);

  const fetchEarnings = async () => {
    if (!user) return;

    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    const { data: jobs, error } = await supabase
      .from('service_requests')
      .select('id, service_type, final_price, completed_at')
      .eq('splasher_id', user.id)
      .eq('status', 'completed')
      .not('final_price', 'is', null)
      .order('completed_at', { ascending: false });

    if (error) {
      console.error('Error fetching earnings:', error);
      setLoading(false);
      return;
    }

    const totalEarnings = jobs?.reduce((sum, job) => sum + (job.final_price || 0), 0) || 0;
    
    const weeklyJobs = jobs?.filter(job => {
      const completedDate = new Date(job.completed_at);
      return completedDate >= weekStart && completedDate <= weekEnd;
    }) || [];
    const weeklyEarnings = weeklyJobs.reduce((sum, job) => sum + (job.final_price || 0), 0);

    const monthlyJobs = jobs?.filter(job => {
      const completedDate = new Date(job.completed_at);
      return completedDate >= monthStart && completedDate <= monthEnd;
    }) || [];
    const monthlyEarnings = monthlyJobs.reduce((sum, job) => sum + (job.final_price || 0), 0);

    setEarnings({
      totalEarnings,
      weeklyEarnings,
      monthlyEarnings,
      completedJobs: jobs?.length || 0,
      recentJobs: jobs?.slice(0, 10) || [],
    });
    setLoading(false);
  };

  const formatServiceType = (type: string) => {
    return type
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  if (loading) {
    return (
      <AppLayout showHeader={false}>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                This Week
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">${earnings.weeklyEarnings.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                This Month
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">${earnings.monthlyEarnings.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card className="col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Total Earnings ({earnings.completedJobs} jobs)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-primary">${earnings.totalEarnings.toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Jobs */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            {earnings.recentJobs.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No completed jobs yet
              </p>
            ) : (
              <div className="space-y-3">
                {earnings.recentJobs.map((job) => (
                  <div
                    key={job.id}
                    className="flex items-center justify-between py-3 border-b border-border last:border-0"
                  >
                    <div>
                      <p className="font-medium">{formatServiceType(job.service_type)}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(job.completed_at), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <p className="font-semibold text-primary">
                      ${job.final_price?.toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Earnings;
