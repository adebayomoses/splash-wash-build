import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useAdminCheck } from '@/hooks/useAdminCheck';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Check, 
  X, 
  Loader2, 
  Users, 
  Car, 
  DollarSign, 
  TrendingUp,
  Clock,
  UserCheck,
  AlertCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import type { Tables } from '@/integrations/supabase/types';

type SplasherApplication = Tables<'splasher_applications'>;
type ServiceRequest = Tables<'service_requests'>;

interface ApplicationWithProfile extends SplasherApplication {
  profiles: { full_name: string; email: string } | null;
}

interface Analytics {
  totalUsers: number;
  totalSplashers: number;
  totalRequests: number;
  completedRequests: number;
  pendingApplications: number;
  totalRevenue: number;
}

const Admin = () => {
  const { user } = useAuth();
  const { isAdmin, loading: adminLoading } = useAdminCheck(user?.id);
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [applications, setApplications] = useState<ApplicationWithProfile[]>([]);
  const [analytics, setAnalytics] = useState<Analytics>({
    totalUsers: 0,
    totalSplashers: 0,
    totalRequests: 0,
    completedRequests: 0,
    pendingApplications: 0,
    totalRevenue: 0,
  });
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    if (!adminLoading && isAdmin) {
      fetchData();
    }
  }, [adminLoading, isAdmin]);

  const fetchData = async () => {
    try {
      // Fetch applications
      const { data: appsOnly, error: appsError } = await supabase
        .from('splasher_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (appsError) throw appsError;

      // Fetch profiles separately
      if (appsOnly && appsOnly.length > 0) {
        const userIds = appsOnly.map(a => a.user_id);
        const { data: profiles } = await supabase
          .from('profiles')
          .select('user_id, full_name, email')
          .in('user_id', userIds);

        const appsWithProfiles = appsOnly.map(app => ({
          ...app,
          profiles: profiles?.find(p => p.user_id === app.user_id) || null
        }));
        setApplications(appsWithProfiles as ApplicationWithProfile[]);
      } else {
        setApplications([]);
      }

      // Fetch analytics
      const [usersResult, splashersResult, requestsResult] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('splasher_profiles').select('id', { count: 'exact', head: true }),
        supabase.from('service_requests').select('*'),
      ]);

      const requests = requestsResult.data || [];
      const completedRequests = requests.filter(r => r.status === 'completed');
      const pendingApps = applications.filter(a => a.status === 'pending').length;
      const totalRevenue = completedRequests.reduce((sum, r) => sum + (r.final_price || 0), 0);

      setAnalytics({
        totalUsers: usersResult.count || 0,
        totalSplashers: splashersResult.count || 0,
        totalRequests: requests.length,
        completedRequests: completedRequests.length,
        pendingApplications: pendingApps,
        totalRevenue,
      });
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApplicationAction = async (applicationId: string, action: 'approved' | 'rejected') => {
    setProcessingId(applicationId);
    
    // Find the application to get user info for email
    const application = applications.find(app => app.id === applicationId);
    
    try {
      const { error } = await supabase
        .from('splasher_applications')
        .update({ status: action })
        .eq('id', applicationId);

      if (error) throw error;

      // Send email notification
      if (application?.profiles?.email) {
        try {
          const { error: emailError } = await supabase.functions.invoke('send-application-email', {
            body: {
              email: application.profiles.email,
              name: application.profiles.full_name || 'Applicant',
              status: action,
            },
          });
          
          if (emailError) {
            console.error('Error sending email:', emailError);
          } else {
            console.log('Email notification sent successfully');
          }
        } catch (emailErr) {
          console.error('Failed to send email notification:', emailErr);
        }
      }

      toast({
        title: action === 'approved' ? 'Application Approved' : 'Application Rejected',
        description: action === 'approved' 
          ? 'The applicant has been granted Splasher access and notified via email.'
          : 'The application has been rejected and the applicant has been notified.',
      });

      // Refresh data
      fetchData();
    } catch (error) {
      console.error('Error updating application:', error);
      toast({
        title: 'Error',
        description: 'Failed to update application. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setProcessingId(null);
    }
  };

  const formatServiceType = (type: string) => {
    return type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  };

  if (adminLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 mx-auto text-destructive mb-4" />
            <h3 className="text-lg font-medium mb-2">Access Denied</h3>
            <p className="text-muted-foreground mb-4">
              You don't have permission to access the admin dashboard.
            </p>
            <Button onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingApplications = applications.filter(a => a.status === 'pending');
  const processedApplications = applications.filter(a => a.status !== 'pending');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center h-16 gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-semibold">Admin Dashboard</h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 pt-24 pb-8">
        {/* Analytics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{analytics.totalUsers}</p>
                  <p className="text-xs text-muted-foreground">Total Users</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-2xl font-bold">{analytics.totalSplashers}</p>
                  <p className="text-xs text-muted-foreground">Splashers</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Car className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-2xl font-bold">{analytics.totalRequests}</p>
                  <p className="text-xs text-muted-foreground">Total Requests</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
                <div>
                  <p className="text-2xl font-bold">{analytics.completedRequests}</p>
                  <p className="text-xs text-muted-foreground">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-500" />
                <div>
                  <p className="text-2xl font-bold">{pendingApplications.length}</p>
                  <p className="text-xs text-muted-foreground">Pending Apps</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">${analytics.totalRevenue.toFixed(0)}</p>
                  <p className="text-xs text-muted-foreground">Revenue</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Applications Management */}
        <Card>
          <CardHeader>
            <CardTitle>Splasher Applications</CardTitle>
            <CardDescription>Review and manage Splasher applications</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pending">
              <TabsList className="mb-4">
                <TabsTrigger value="pending">
                  Pending ({pendingApplications.length})
                </TabsTrigger>
                <TabsTrigger value="processed">
                  Processed ({processedApplications.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pending">
                {pendingApplications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No pending applications
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingApplications.map((app) => (
                      <Card key={app.id}>
                        <CardContent className="p-3 sm:p-4">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                <p className="font-medium">
                                  {app.profiles?.full_name || 'Unknown User'}
                                </p>
                                <Badge variant="outline" className="bg-orange-500/10 text-orange-600">
                                  Pending
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2 truncate">
                                {app.profiles?.email || 'No email'}
                              </p>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2 text-sm">
                                <div>
                                  <span className="text-muted-foreground">Vehicle:</span>{' '}
                                  {app.vehicle_year} {app.vehicle_type}
                                </div>
                                <div>
                                  <span className="text-muted-foreground">License:</span>{' '}
                                  {app.license_number}
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Experience:</span>{' '}
                                  {app.experience_years || 0} years
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Applied:</span>{' '}
                                  {format(new Date(app.created_at), 'MMM d, yyyy')}
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {app.services_offered.map((service) => (
                                  <Badge key={service} variant="secondary" className="text-xs">
                                    {formatServiceType(service)}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex gap-2 self-end sm:self-start">
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-destructive hover:bg-destructive hover:text-destructive-foreground min-h-[44px] min-w-[44px]"
                                onClick={() => handleApplicationAction(app.id, 'rejected')}
                                disabled={processingId === app.id}
                              >
                                {processingId === app.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <X className="w-4 h-4" />
                                )}
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => handleApplicationAction(app.id, 'approved')}
                                disabled={processingId === app.id}
                                className="min-h-[44px] min-w-[44px]"
                              >
                                {processingId === app.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Check className="w-4 h-4" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="processed">
                {processedApplications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No processed applications
                  </div>
                ) : (
                  <div className="space-y-4">
                    {processedApplications.map((app) => (
                      <Card key={app.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <p className="font-medium">
                                  {app.profiles?.full_name || 'Unknown User'}
                                </p>
                                <Badge 
                                  variant="outline" 
                                  className={app.status === 'approved' 
                                    ? 'bg-green-500/10 text-green-600' 
                                    : 'bg-destructive/10 text-destructive'
                                  }
                                >
                                  {app.status === 'approved' ? 'Approved' : 'Rejected'}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {app.profiles?.email || 'No email'}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Applied: {format(new Date(app.created_at), 'MMM d, yyyy')}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Admin;
