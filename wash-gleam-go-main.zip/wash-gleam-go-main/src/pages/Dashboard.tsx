import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useViewMode } from '@/contexts/ViewModeContext';
import { useNavigate } from 'react-router-dom';
import CustomerDashboard from '@/components/dashboard/CustomerDashboard';
import SplasherDashboard from '@/components/dashboard/SplasherDashboard';
import AppLayout from '@/components/layouts/AppLayout';

const Dashboard = () => {
  const { user } = useAuth();
  const { viewMode, openNewRequestRef } = useViewMode();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  return (
    <AppLayout>
      {viewMode === 'customer' ? (
        <CustomerDashboard onOpenNewRequestRef={openNewRequestRef} />
      ) : (
        <SplasherDashboard />
      )}
    </AppLayout>
  );
};

export default Dashboard;
