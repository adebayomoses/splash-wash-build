import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Car, CheckCircle, Loader2, MapPin, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import type { Tables } from '@/integrations/supabase/types';
import AppLayout from '@/components/layouts/AppLayout';

type ServiceRequest = Tables<'service_requests'>;

const ServiceHistory = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);

  useEffect(() => {
    if (user) {
      fetchHistory();
    }
  }, [user]);

  const fetchHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('service_requests')
        .select('*')
        .eq('customer_id', user!.id)
        .in('status', ['completed', 'cancelled'])
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRequests(data || []);
    } catch (error) {
      console.error('Error fetching history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatServiceType = (type: string) => {
    return type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  };

  if (loading) {
    return (
      <AppLayout showHeader={false}>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <h1 className="text-2xl font-bold mb-6">Service History</h1>
        
        {requests.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No Service History</h3>
              <p className="text-muted-foreground mb-4">
                You don't have any completed or cancelled requests yet.
              </p>
              <Button onClick={() => navigate('/dashboard')}>
                Book a Service
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {requests.map((request) => (
              <Card key={request.id} className="overflow-hidden">
                <CardContent className="p-3 sm:p-4">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 sm:gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        {request.status === 'completed' ? (
                          <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Completed
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-destructive/10 text-destructive border-destructive/20">
                            <XCircle className="w-3 h-3 mr-1" />
                            Cancelled
                          </Badge>
                        )}
                        <Badge variant="outline">
                          {formatServiceType(request.service_type)}
                        </Badge>
                      </div>

                      <div className="flex flex-wrap items-center gap-1 sm:gap-2 text-sm mb-2">
                        <Car className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        <span className="font-medium">
                          {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                        </span>
                        {request.vehicle_color && (
                          <span className="text-muted-foreground">({request.vehicle_color})</span>
                        )}
                      </div>

                      <div className="flex items-start gap-2 text-sm text-muted-foreground mb-2">
                        <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
                        <span className="line-clamp-2 sm:line-clamp-1">{request.location_address}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4 flex-shrink-0" />
                        <span className="text-xs sm:text-sm">
                          {format(new Date(request.created_at), 'MMM d, yyyy')} at {format(new Date(request.created_at), 'h:mm a')}
                        </span>
                      </div>
                    </div>

                    {request.final_price && (
                      <div className="text-left sm:text-right pt-2 sm:pt-0 border-t sm:border-t-0 border-border">
                        <p className="text-lg font-semibold text-primary">
                          ${request.final_price.toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground">Final</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default ServiceHistory;
