// Simple notification sound using Web Audio API
export const playNotificationSound = (type: 'newJob' | 'success' | 'alert' = 'newJob') => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    const configs = {
      newJob: { frequency: 800, duration: 0.15, count: 2, gap: 0.1 },
      success: { frequency: 600, duration: 0.2, count: 1, gap: 0 },
      alert: { frequency: 400, duration: 0.3, count: 3, gap: 0.15 },
    };
    
    const config = configs[type];
    
    const playBeep = (startTime: number, frequency: number, duration: number) => {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = frequency;
      oscillator.type = 'sine';
      
      // Fade in and out for smoother sound
      gainNode.gain.setValueAtTime(0, startTime);
      gainNode.gain.linearRampToValueAtTime(0.3, startTime + 0.02);
      gainNode.gain.linearRampToValueAtTime(0, startTime + duration);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + duration);
    };
    
    let time = audioContext.currentTime;
    for (let i = 0; i < config.count; i++) {
      playBeep(time, config.frequency + (i * 100), config.duration);
      time += config.duration + config.gap;
    }
    
    // Clean up after sounds finish
    setTimeout(() => audioContext.close(), (time - audioContext.currentTime + 1) * 1000);
    
  } catch (error) {
    console.log('Could not play notification sound:', error);
  }
};
