-- Add sound notifications preference to profiles table
ALTER TABLE public.profiles 
ADD COLUMN sound_notifications_enabled BOOLEAN DEFAULT true;