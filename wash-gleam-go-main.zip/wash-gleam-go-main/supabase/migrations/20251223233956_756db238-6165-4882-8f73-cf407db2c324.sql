-- Allow admins to view all splasher applications
CREATE POLICY "Admins can view all applications"
ON public.splasher_applications
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to update splasher applications (approve/reject)
CREATE POLICY "Admins can update applications"
ON public.splasher_applications
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to view all service requests for analytics
CREATE POLICY "Admins can view all requests"
ON public.service_requests
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to view all profiles for application management
CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create function to handle application approval
CREATE OR REPLACE FUNCTION public.handle_application_approval()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- When application is approved, add splasher role and create splasher profile
  IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
    -- Add splasher role if not exists
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.user_id, 'splasher')
    ON CONFLICT (user_id, role) DO NOTHING;
    
    -- Create splasher profile if not exists
    INSERT INTO public.splasher_profiles (user_id, services_offered)
    VALUES (NEW.user_id, NEW.services_offered)
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for application approval
DROP TRIGGER IF EXISTS on_application_approval ON public.splasher_applications;
CREATE TRIGGER on_application_approval
  AFTER UPDATE ON public.splasher_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_application_approval();