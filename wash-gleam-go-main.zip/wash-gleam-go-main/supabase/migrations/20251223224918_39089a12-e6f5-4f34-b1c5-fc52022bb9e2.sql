-- Create storage bucket for car images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('car-images', 'car-images', true);

-- RLS policy: Allow authenticated users to upload car images
CREATE POLICY "Users can upload car images" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'car-images');

-- RLS policy: Allow users to update their own images
CREATE POLICY "Users can update own car images" ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'car-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- RLS policy: Allow users to delete their own images
CREATE POLICY "Users can delete own car images" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'car-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- RLS policy: Public read access for car images
CREATE POLICY "Public can view car images" ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'car-images');

-- Add vehicle_image_url column to service_requests
ALTER TABLE public.service_requests 
ADD COLUMN vehicle_image_url TEXT;