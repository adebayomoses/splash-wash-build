import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");



const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ApplicationEmailRequest {
  email: string;
  name: string;
  status: "approved" | "rejected";
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, name, status }: ApplicationEmailRequest = await req.json();

    console.log(`Sending ${status} email to ${email} for ${name}`);

    const isApproved = status === "approved";
    
    const subject = isApproved 
      ? "🎉 Your Splasher Application Has Been Approved!" 
      : "Update on Your Splasher Application";

    const html = isApproved
      ? `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #0ea5e9;">Congratulations, ${name}! 🎉</h1>
          <p style="font-size: 16px; color: #333; line-height: 1.6;">
            Great news! Your application to become a Splasher has been <strong style="color: #22c55e;">approved</strong>.
          </p>
          <p style="font-size: 16px; color: #333; line-height: 1.6;">
            You can now log in to your dashboard and start accepting car wash requests in your area.
          </p>
          <div style="margin: 30px 0;">
            <a href="${Deno.env.get("SITE_URL") || "https://splash.app"}/dashboard" 
               style="background-color: #0ea5e9; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: 600;">
              Go to Dashboard
            </a>
          </div>
          <p style="font-size: 14px; color: #666;">
            Welcome to the Splash team! We're excited to have you on board.
          </p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="font-size: 12px; color: #999;">
            This email was sent by Splash. If you didn't apply to become a Splasher, please ignore this email.
          </p>
        </div>
      `
      : `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #0ea5e9;">Hello, ${name}</h1>
          <p style="font-size: 16px; color: #333; line-height: 1.6;">
            Thank you for your interest in becoming a Splasher. After reviewing your application, we regret to inform you that we are unable to approve it at this time.
          </p>
          <p style="font-size: 16px; color: #333; line-height: 1.6;">
            This decision may be due to incomplete information, requirements not being met, or current availability in your area.
          </p>
          <p style="font-size: 16px; color: #333; line-height: 1.6;">
            You're welcome to reapply in the future if your circumstances change.
          </p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="font-size: 12px; color: #999;">
            This email was sent by Splash. If you have any questions, please contact our support team.
          </p>
        </div>
      `;

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Splash <onboarding@resend.dev>",
        to: [email],
        subject,
        html,
      }),
    });

    const emailData = await emailResponse.json();

    console.log("Email sent successfully:", emailData);

    return new Response(JSON.stringify({ success: true, data: emailData }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-application-email function:", error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
